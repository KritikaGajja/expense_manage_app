import 'package:expense_manager_app/screens/home/fragments/frag_stat_page.dart';
import 'package:expense_manager_app/screens/home/fragments/frag_transaction_page.dart';
import 'package:flutter/material.dart';
class HomePage extends StatefulWidget {
  var currentIndex = 0;
  var arrPages =[
    FragTransactionPage(),
    FragStatPage()
  ];
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(),
    );
  }
}

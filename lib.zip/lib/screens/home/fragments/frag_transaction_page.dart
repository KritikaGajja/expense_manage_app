import 'package:flutter/material.dart';
class FragTransactionPage extends StatelessWidget {
  
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}

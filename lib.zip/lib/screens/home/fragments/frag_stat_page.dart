import 'package:flutter/material.dart';
class FragStatPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
